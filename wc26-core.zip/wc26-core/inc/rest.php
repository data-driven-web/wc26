<?php
namespace WC26Core;
use WP_REST_Request;
use WP_Query;
if (!defined('ABSPATH')) { exit; }

function register_rest_routes() {
    register_rest_route('wc26/v1', '/matches', [
        'methods'  => 'GET',
        'callback' => __NAMESPACE__ . '\get_matches',
        'args'     => [
            'status' => ['type' => 'string','enum' => ['upcoming','completed','all'],'default' => 'upcoming'],
            'per_page' => ['type' => 'integer','default' => 20],
        ],
        'permission_callback' => '__return_true',
    ]);
}
add_action('rest_api_init', __NAMESPACE__ . '\register_rest_routes');

function get_matches(WP_REST_Request $req) {
    $status = $req->get_param('status') ?: 'upcoming';
    $per = max(1, min(100, intval($req->get_param('per_page'))));

    $meta_key = 'match_datetime';
    $now = current_time('timestamp');

    $meta_query = [];
    if ($status === 'upcoming') {
        $meta_query = [['key' => $meta_key, 'value' => $now, 'compare' => '>=', 'type' => 'NUMERIC']];
        $order = 'ASC';
    } elseif ($status === 'completed') {
        $meta_query = [['key' => $meta_key, 'value' => $now, 'compare' => '<', 'type' => 'NUMERIC']];
        $order = 'DESC';
    } else {
        $order = 'ASC';
    }

    $q = new WP_Query([
        'post_type' => 'match',
        'posts_per_page' => $per,
        'meta_key' => $meta_key,
        'orderby' => 'meta_value_num',
        'order' => $order,
        'meta_query' => $meta_query,
    ]);

    $data = [];
    foreach ($q->posts as $p) {
        $data[] = [
            'id' => $p->ID,
            'title' => get_the_title($p),
            'link' => get_permalink($p),
            'datetime' => intval(get_post_meta($p->ID, 'match_datetime', true)),
            'team_home' => get_post_meta($p->ID, 'team_home', true),
            'team_away' => get_post_meta($p->ID, 'team_away', true),
            'stadium' => get_post_meta($p->ID, 'stadium', true),
            'group' => wp_get_post_terms($p->ID, 'group', ['fields' => 'names']),
        ];
    }
    return rest_ensure_response(['matches' => $data, 'count' => count($data)]);
}
