<?php
namespace WC26Core;
if (!defined('ABSPATH')) { exit; }

function jsonld_single_match() {
    if (!is_singular('match')) return;

    global $post;
    $ts = intval(get_post_meta($post->ID, 'match_datetime', true));
    $home = get_post_meta($post->ID, 'team_home', true);
    $away = get_post_meta($post->ID, 'team_away', true);
    $stadium = get_post_meta($post->ID, 'stadium', true);

    if (!$ts || !$home || !$away) return;

    $iso = gmdate('c', $ts);
    $data = [
        "@context" => "https://schema.org",
        "@type" => "SportsEvent",
        "name" => get_the_title($post),
        "startDate" => $iso,
        "location" => [
            "@type" => "Place",
            "name" => $stadium or "Stadium",
        ],
        "competitor" => [
            ["@type" => "SportsTeam", "name" => $home],
            ["@type" => "SportsTeam", "name" => $away],
        ],
        "sport" => "Soccer",
        "eventAttendanceMode" => "https://schema.org/OfflineEventAttendanceMode"
    ];

    echo '<script type="application/ld+json">' . wp_json_encode($data) . '</script>';
}
add_action('wp_head', __NAMESPACE__ . '\jsonld_single_match', 20);
