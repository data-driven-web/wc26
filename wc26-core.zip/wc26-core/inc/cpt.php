<?php
namespace WC26Core;
if (!defined('ABSPATH')) { exit; }

function register_post_types() {
    register_post_type('team', [
        'label' => 'Teams',
        'public' => true,
        'show_in_rest' => true,
        'menu_position' => 5,
        'supports' => ['title','editor','thumbnail','excerpt','custom-fields'],
        'has_archive' => true,
        'rewrite' => ['slug' => 'teams'],
    ]);

    register_post_type('stadium', [
        'label' => 'Stadiums',
        'public' => true,
        'show_in_rest' => true,
        'menu_position' => 6,
        'supports' => ['title','editor','thumbnail','excerpt','custom-fields'],
        'has_archive' => true,
        'rewrite' => ['slug' => 'stadiums'],
    ]);

    register_post_type('match', [
        'label' => 'Matches',
        'public' => true,
        'show_in_rest' => true,
        'menu_position' => 7,
        'supports' => ['title','editor','custom-fields','excerpt'],
        'has_archive' => true,
        'rewrite' => ['slug' => 'matches'],
    ]);

    register_taxonomy('group', ['team','match'], [
        'label' => 'Groups',
        'public' => true,
        'show_in_rest' => true,
        'hierarchical' => false,
        'rewrite' => ['slug' => 'group'],
    ]);
}
add_action('init', __NAMESPACE__ . '\register_post_types');
