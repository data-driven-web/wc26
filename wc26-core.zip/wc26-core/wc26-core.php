<?php
/**
 * Plugin Name: WC26 Core
 * Description: Core data model & APIs for 2026 World Cup Guide (CPTs, taxonomies, REST, JSON-LD).
 * Author: Data Driven Tech LLC
 * Version: 0.1.0
 * Requires at least: 6.5
 * Requires PHP: 8.1
 */
namespace WC26Core;
if (!defined('ABSPATH')) { exit; }
const VERSION = '0.1.0';

require_once __DIR__ . '/inc/cpt.php';
require_once __DIR__ . '/inc/rest.php';
require_once __DIR__ . '/inc/jsonld.php';

register_activation_hook(__FILE__, function () {
    register_post_types();
    flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules();
});
